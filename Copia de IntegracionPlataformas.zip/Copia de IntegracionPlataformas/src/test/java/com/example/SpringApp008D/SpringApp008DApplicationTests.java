package com.example.SpringApp008D;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringApp008DApplicationTests {

	@Test
	void contextLoads() {
	}

}
